class <%= class_name %> < Sidebar
  # display_name "<%= class_name.underscore.humanize %>" # Default
  description "Describe your sidebar here"

  # Check the other sidebars for the sort of thing you can do with setting
  # declarations

  def parse_request(contents, params)
    # contents is a list of the items being rendered on the current page
    # params is the params hash for the current request

    # Take a look at (eg) the amazon sidebar for examples of what gets done here
    # If your sidebar doesn't depend on the request or the contents, you don't
    # need to do anything here.
  end
end
