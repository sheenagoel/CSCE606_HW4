require 'spec_helper'

describe Notification do
  # Replace this with your real tests.
  it "test_truth" do
    assert true
  end
end
