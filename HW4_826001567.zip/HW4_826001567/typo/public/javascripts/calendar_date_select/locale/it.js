Date.weekdays = $w('Lu Ma Me Gi Ve Sa Do');
Date.months = $w('Gennaio Febbraio Marzo Aprile Maggio Giugno Luglio Agosto Settembre Ottobre Novembre Dicembre');
Date.first_day_of_week = 1;
_translations = {
  "OK": "OK",
  "Now": "Ora",
  "Today": "Oggi",
  "Clear": "Cancella"
}
